<!DOCTYPE html>
<html>
<head>
	<title>Admin Work</title>
</head>
<body>

	<a href="add_doctor.php">
		<button>Add Doctor</button>
	</a>
	<br>
	<a href="delete.php">
		<button>Remove Doctor</button>
	</a>
	<br>

	<a href="add_medicine.php">
		
		<button>Medicine</button>
	</a>

	<br>
	<a href="add_medicine.php">
		
		<button>Update</button>
	</a>

	<br>
	<br>
	<br>
	<a href="login.php">
		
		<button>Log Out</button>
	</a>



</body>
</html>