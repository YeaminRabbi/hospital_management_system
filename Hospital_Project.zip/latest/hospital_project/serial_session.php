
<?php
session_start();
$serial=$_POST['serial'];

$_SESSION['serial']=$serial;

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Prescription</title>
</head>
<body>

	<a href="index.php">
		<button>ADD Medicine</button>
	</a>

</body>
</html>