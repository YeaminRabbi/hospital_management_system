<?php

$medname = $_POST['medname'];
$medtype = $_POST['medtype'];
if (!empty($medname) || !empty($medtype) ) 
{
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "hospital";

    //DATABASE connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    
    if (mysqli_connect_error()) {
        die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    }

    else {

    
        $query = "INSERT INTO medicine (med_name, med_type)
VALUES ('$medname', '$medtype');";
        $a = mysqli_query($conn, $query);
         
        echo "<script>location.assign('admin_work.php');</script>";
    

    }
} 
?>