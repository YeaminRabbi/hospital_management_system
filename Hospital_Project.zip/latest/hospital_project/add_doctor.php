<!DOCTYPE HTML>
<html>
<head>
  <title>Doctor Form</title>
</head>
<body>

 <form action="add_doctor_index.php" method="POST">
  

  <table>


   <tr>
    <td>Name :</td>
    <td><input type="text" name="name" required></td>
   </tr>




   <tr>
    <td>Username :</td>
    <td><input type="text" name="username" required></td>
   </tr>
   <tr>



   <tr>
    <td>Password :</td>
    <td><input type="password" name="password" required></td>
   </tr>



   <tr>
    <td>Degree :</td>
    <td><input type="text" name="degree"></td>
   </tr> 


<tr>
    <td>Doctor Type :</td>
    <td><input type="text" name="type" required></td>
   </tr>


   <tr>
    <td>Email :</td>
    <td><input type="email" name="email"></td>
   </tr> 


   <tr>
    <td>Gender :</td>
    <td>
     <input type="radio" name="gender" value="male" required>Male
     <input type="radio" name="gender" value="female" required>Female
    </td>
   </tr>  
   


   <td>Birthdate :</td>
   <td><input type="text" name="birthdate" required></td>
   </tr>



   <tr>
    <td>Address :</td>
    <td><input type="text" name="address" required></td>
   </tr>



   
   
   <tr>
    <td>Phone no :</td>
    <td>
     <input type="phone" name="phone" required>
    </td>
   </tr>
   <tr>
    <td><input type="submit" value="ADD To Database"></td>
   </tr>

  </table>
 </form>
</body>
</html>