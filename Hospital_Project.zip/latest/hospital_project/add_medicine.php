<!DOCTYPE HTML>
<html>
<head>
  <title>Doctor Form</title>
</head>
<body>

 <form action="add_medicine_index.php" method="POST">
  

  <table>


   <tr>
    <td>Medicine Name :</td>
    <td><input type="text" name="medname" required></td>
   </tr>




   <tr>
    <td>Medicine Type:</td>
    <td><input type="text" name="medtype" required></td>
   </tr>
   <tr>

    <td><input type="submit" value="ADD To Database"></td>
   </tr>

  </table>
 </form>
</body>
</html>