<!DOCTYPE html>
<html>
<head>
	<title>Check Appointments</title>
	<style type="text/css">
		table {
			border-collapse: collapse;
			width: 80%;
			color: #00000;
			font-family: monospace;
			font-size: 18px;
			text-align: left;
		}

		th{
			background-color: #000000;
			color: black;
		}
	</style>
</head>
<body>


	<table>
		<tr>
			<td>Serial No.</td>
			<td>Patient Name</td>
			<td>Type</td>
			
		</tr>

		<?php
		session_start();
		$doctor_username=$_SESSION['doc_username'];

			$conn = mysqli_connect("localhost", "root", "", "hospital");

			if($conn-> connect_error)
			{
				die("Connection failed:". $conn-> connect_error);
			}




			$sql = "SELECT apt.ap_id, apt.patient_name, doc.doc_type  from appointment as apt join doctor as doc
			on(doc.doc_id=apt.doctordoc_id)
			where doc.doc_username Like '$doctor_username'";
			
			$result = $conn-> query($sql);
			if($result-> num_rows >0)
			{
				while ($row = $result-> fetch_assoc()) {
						echo "<tr><td>". $row["ap_id"] ."</td><td>". $row["patient_name"] ."</td><td>". $row["doc_type"] ."</td></tr>";										
					}
						echo "</table>";
			}
			else {
				echo "0 result";
			}
			$conn-> close();
		?>

	</table>


	<form method="post" action="serial_session.php">
		<br>
		<input type="text" name="serial" placeholder="Serial No." required>
		<input type="submit" value="Prescribe" name="submit">


	</form>
	
	<br>
	<a href="doctor_profile.php">
		<button>Back</button>
	</a>
	<br><br>
	<a href="index.html">
		<button>Logout</button>
	</a>
	
</body>
</html>


