


<!Doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Medicine Search</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <script>
  $(function() {
    $( "#medicine" ).autocomplete({
      source: 'search.php'
    });
  });
  </script>
</head>
<body>
 
 <div class="ui-widget">

  <form action="prescription.php" method="post">
    

    <label for="medicine">Medicine: </label>
  <input id="medicine" name="med">
  <input type="submit" value="ADD">

  
  </form>
  

</div>
</body>
</html>



<!DOCTYPE html>
<html>
<head>
  <title></title>

  <style type="text/css">
    table {
      border-collapse: collapse;
      width: 80%;
      color: #00000;
      font-family: monospace;
      font-size: 18px;
      text-align: left;
    }

    th{
      background-color: #000000;
      color: black;
    }
  </style>
</head>


<body>


<h3>Prescribing to:</h3>


<table>
   <tr>
      <td>Patient Name</td>
      <td>Patient Age</td>
      <td>Gender</td>
      
    </tr>

    <?php
    session_start();
    $doctor_username=$_SESSION['doc_username'];

    $serial=$_SESSION['serial'];


      $conn = mysqli_connect("localhost", "root", "", "hospital");

      if($conn-> connect_error)
      {
        die("Connection failed:". $conn-> connect_error);
      }




      $sql = "SELECT p.p_name, p.p_age ,p.p_gender from patient as p join appointment as ap
      on(p.p_id=ap.patientp_id) 
      where ap.ap_id='$serial'";
      
      $result = $conn-> query($sql);
      if($result-> num_rows >0)
      {
        while ($row = $result-> fetch_assoc()) {
            echo "<tr><td>". $row["p_name"] ."</td><td>". $row["p_age"] ."</td><td>". $row["p_gender"] ."</td></tr>";                   
          }
            echo "</table>";
      }
      else {
        echo "";
      }

      echo $row["p_name"];
      $conn-> close();


    ?>

  </table>







<h3>Medicine List:</h3>



<table>
   

    <?php
   # session_start();
    $doctor_username=$_SESSION['doc_username'];

    $serial=$_SESSION['serial'];


      $conn = mysqli_connect("localhost", "root", "", "hospital");

      if($conn-> connect_error)
      {
        die("Connection failed:". $conn-> connect_error);
      }




      $sql = "SELECT pre_med from prescription as prep join doctor as doc
      on(doc.doc_id=prep.doctordoc_id)
      where doc.doc_username Like '$doctor_username' AND prep.appointment_id='$serial'";
      
      $result = $conn-> query($sql);
      if($result-> num_rows >0)
      {
        while ($row = $result-> fetch_assoc()) {
            echo "<tr><td>". $row["pre_med"] ."</td></tr>";                   
          }
            echo "</table>";
      }
      else {
        echo "";
      }
      $conn-> close();
    ?>

  </table>





<br>
  <a href="doctor_profile.php">
    <button>BACK</button>
  </a>




</body>
</html>