


<!DOCTYPE html>
<html>
<head>
	<title>Patient Profile</title>
</head>
<body>

	<a href="doctor_appointment_check.php">
		<button>Appointment List</button>
	</a>
	<br>
	<br>
	<a href="index.html">
		<button>Log out</button>
	</a>

	
</body>
</html>

