<!DOCTYPE html>
<html>
<head>
	<title>Check Appointments</title>
	<style type="text/css">
		.content{

			border-collapse: collapse;
			margin: 25px 0;
			font-size: 18px;
			min-width: 80%;
			border-radius: 5px;
			overflow: hidden;
			box-shadow: 0 0 20px rgb(0, 0, 0, 0.15);
		}
		.content thead tr{
			background-color: #009879;
			color: #ffffff;
			text-align: left;
			font-weight: bold;
		}
		.content th,
		.content td{
			padding: 12px 15px;
		}
		.content tr{
			border-bottom: 1px solid #dddddd;
		}
		.content tr:nth-of-type(even){
			background-color: #f3f3f3;
		}
		.content tr:last-of-type{
			border-bottom: 2px solid  #009879;
		}
	</style>
</head>
<body>



	<table class='content'>
		<thead>
			<tr>
			<th>Serial No.</th>
			<th>Patient Name</th>
			
			
		</tr>
		</thead>
		

		<?php
		session_start();
		$patient_username=$_SESSION['username'];
		$doctorname= $_POST['doctorname'];
			$conn = mysqli_connect("localhost", "root", "", "hospital");

			if($conn-> connect_error)
			{
				die("Connection failed:". $conn-> connect_error);
			}


				########fetching patient id using username
			$query ="SELECT * FROM `patient` where p_username='$patient_username'";

	$result2 = mysqli_query($conn, $query);

	$row2 = mysqli_fetch_array($result2);

	$patient_id= $row2[0];
	#################

			$sql = "SELECT p.pre_med, d.doc_name FROM prescription as p 
			join doctor as d
			on(p.doctordoc_id=d.doc_id) where doc_name LIKE '%$doctorname'";


			$result = $conn-> query($sql);
			if($result-> num_rows >0)
			{
				while ($row = $result-> fetch_assoc()) {
						echo "<tr><td>". $row["pre_med"] ."</td><td>". $row["doc_name"] ."</td></tr>";										
					}
						echo "</table>";
			}
			else {
				echo "";
			}
			$conn-> close();
		?>

	</table>
	
	<br>
	<a href="patient_profile.php">
		<button>Back</button>
	</a>
	<br><br>
	<a href="index.html">
		<button>Logout</button>
	</a>
	
</body>
</html>


