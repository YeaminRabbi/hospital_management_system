<!DOCTYPE html>

<html>

	<head>
		<title>My Site</title>
		
		<style>
		
		</style>
	</head>

	<body>
		<form action="delete_index1.php" method="post">


<table>
	
    <tr>
    	<td>Doctor ID :</td>
    	<td><input type="text" name="doc_id" required></td>
    	<td>
    		<input type="submit" value="Confirm">
    	</td>
    </tr>

</table>
		</form>
	</body>

</html>