<?php


$up_username = $_POST['up_username'];

if (!empty($up_username) ) 
{
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "hospital";

    //DATABASE connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    
    if (mysqli_connect_error()) {
        die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    }

    else {

    
        $query = "UPDATE patient SET p_password='111111' WHERE p_username='$up_username' ";
        $a = mysqli_query($conn, $query);
        echo "Update Succescfully";  

         
    }
   # echo "<script>location.assign('login.php');</script>"; 
} 
?>