<?php


$doc_id = $_POST['doc_id'];

if (!empty($doc_id) ) 
{
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "hospital";

    //DATABASE connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    
    if (mysqli_connect_error()) {
        die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    }

    else {

    
        $query = "DELETE FROM doctor WHERE doc_id='$doc_id' ";
        $a = mysqli_query($conn, $query);
        echo "Delete Succescfully";  
        echo "<script>location.assign('admin_work.php');</script>";
    

         
    }
   # echo "<script>location.assign('login.php');</script>"; 
} 
?>