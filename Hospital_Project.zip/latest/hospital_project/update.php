<!DOCTYPE html>

<html>

	<head>
		<title>My Site</title>
		
		<style>
		
		</style>
	</head>

	<body>
		<form action="update_index.php" method="post">


<table>
	
    <tr>
    	<td>User Name :</td>
    	<td><input type="text" name="up_username" required></td>
    	<td>
    		<input type="submit" value="Confirm">
    	</td>
    </tr>

</table>
		</form>
	</body>

</html>