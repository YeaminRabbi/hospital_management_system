<!DOCTYPE html>
<html>
<head>
	<title>Doctor List</title>
	<style type="text/css">
	
		.content{

			border-collapse: collapse;
			margin: 25px 0;
			font-size: 18px;
			min-width: 80%;
			border-radius: 5px;
			overflow: hidden;
			box-shadow: 0 0 20px rgb(0, 0, 0, 0.15);
		}
		.content thead tr{
			background-color: #009879;
			color: #ffffff;
			text-align: left;
			font-weight: bold;
		}
		.content th,
		.content td{
			padding: 12px 15px;
		}
		.content tr{
			border-bottom: 1px solid #dddddd;
		}
		.content tr:nth-of-type(even){
			background-color: #f3f3f3;
		}
		.content tr:last-of-type{
			border-bottom: 2px solid  #009879;
		}
		a{
		text-decoration: none;
		padding: 5px;
		display: block;
		margin-left: 30%;
		margin-right: 60%;
		list-style: none;
		border: 2px solid black;
		font-size: 25px;
		font-weight: bold;
		border-radius: 15px;
		text-align: center;
		background: #009879;
		color: white;
	}
	a:hover{
		background: transparent;
		color: #009879;
	}

	</style>
</head>
<body>


	<table class="content">
		<thead>
			<tr>
				<th>Name</th>
				<th>Contact No.</th>
				<th>Email</th>
			</tr>
		</thead>
		

		<?php
#		session_start();

#			$value = $_SESSION['userdata'];

#			echo $value;

			#session_destroy();



  
			$conn = mysqli_connect("localhost", "root", "", "hospital");

			if($conn-> connect_error)
			{
				die("Connection failed:". $conn-> connect_error);
			}

			$sql = "SELECT doc_name, doc_mobile, doc_email from doctor";
			$result = $conn-> query($sql);
			if($result-> num_rows >0)
			{
				while ($row = $result-> fetch_assoc()) {
						echo "<tr><td>". $row["doc_name"] ."</td><td>". $row["doc_mobile"] ."</td><td>". $row["doc_email"] ."</td></tr>";					
					}
						echo "</table>";
			}
			else {
				echo "0 result";
			}
			$conn-> close();
		?>

	</table>

	<br>
	<br>
	<a href="patient_profile.php">Back
		
	</a>

</body>
</html>

