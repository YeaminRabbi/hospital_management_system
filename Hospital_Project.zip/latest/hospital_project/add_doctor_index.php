<?php
$doc_type= $_POST['type'];
$birthdate= $_POST['birthdate'];
$name= $_POST['name'];
$address= $_POST['address'];
$name= $_POST['name'];
$username = $_POST['username'];
$password = $_POST['password'];
$gender = $_POST['gender'];
$degree = $_POST['degree'];
$email = $_POST['email'];
$phone = $_POST['phone'];
if (!empty($username) || !empty($password) || !empty($gender) || !empty($email) || !empty($address) || !empty($phone)|| !empty($name)   ||  !empty($degree)  ||  !empty($doc_type)) 
{
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "hospital";

    //DATABASE connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    
    if (mysqli_connect_error()) {
        die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    }

    else {

    
        $query = "INSERT INTO doctor 
        VALUES ('','$name','$birthdate','$gender','$degree','$phone','$email','$address','$password','$username', '$doc_type')";
        $a = mysqli_query($conn, $query);
         
        echo "<script>location.assign('admin_work.php');</script>";
    

    }
} 
?>