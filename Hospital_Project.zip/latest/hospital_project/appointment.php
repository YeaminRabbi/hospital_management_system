<!DOCTYPE html>
<html>
<head>
	<title>Appointment</title>
	<style type="text/css">
		.content{

			border-collapse: collapse;
			margin: 25px 0;
			font-size: 18px;
			min-width: 80%;
			border-radius: 5px;
			overflow: hidden;
			box-shadow: 0 0 20px rgb(0, 0, 0, 0.15);
		}
		.content thead tr{
			background-color: #009879;
			color: #ffffff;
			text-align: left;
			font-weight: bold;
		}
		.content th,
		.content td{
			padding: 12px 15px;
		}
		.content tr{
			border-bottom: 1px solid #dddddd;
		}
		.content tr:nth-of-type(even){
			background-color: #f3f3f3;
		}
		.content tr:last-of-type{
			border-bottom: 2px solid  #009879;
		}
	</style>
</head>
<body>


	<table class="content">
		<thead>
			<tr>
				<th>ID</th>
				<th>Name</th>
				<th>Type</th>
			</tr>
		</thead>
		

		<?php
#		session_start();

#			$value = $_SESSION['userdata'];

#			echo $value;

			#session_destroy();

			$conn = mysqli_connect("localhost", "root", "", "hospital");

			if($conn-> connect_error)
			{
				die("Connection failed:". $conn-> connect_error);
			}

			$sql = "SELECT doc_id, doc_name, doc_type from doctor
			where available<2";
			$result = $conn-> query($sql);
			if($result-> num_rows >0)
			{
				while ($row = $result-> fetch_assoc()) {
						echo "<tr><td>". $row["doc_id"] ."</td><td>". $row["doc_name"] ."</td><td>". $row["doc_type"] ."</td></tr>";					
					}
						echo "</table>";
			}
			else {
				echo "";
			}
			$conn-> close();
		?>

	</table>

	<br>
	<br>

	<form action="appointment_index.php" method="POST">
		<h1>Appoint</h1>
	<p>Enter Doctor ID:</p>
	<input type="text" name="input_docID" required>
	<input type="submit" value="Confirm">
	</form>
	
</body>
</html>


