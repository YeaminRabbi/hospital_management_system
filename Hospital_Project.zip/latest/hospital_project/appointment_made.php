<!DOCTYPE html>
<html>
<head>
	<title>Doctor List</title>
	<style type="text/css">
		table {
			border-collapse: collapse;
			width: 80%;
			color: #00000;
			font-family: monospace;
			font-size: 18px;
			text-align: left;
		}

		th{
			background-color: #000000;
			color: black;
		}
	</style>
</head>
<body>


	<table>
		<tr>
			<td>ID</td>
			<td>Name</td>
			<td>Tpye</td>
		</tr>

		<?php

			#$doc_type=$_POST['doctor_type'];

			$conn = mysqli_connect("localhost", "root", "", "hospital");

			if($conn-> connect_error)
			{
				die("Connection failed:". $conn-> connect_error);
			}



##############


#############


			$sql = "SELECT doc_id, doc_name, doc_type from doctor
			WHERE doc_type = 'Heart'";
			$result = $conn-> query($sql);
			if($result-> num_rows >0)
			{
				while ($row = $result-> fetch_assoc()) {
						echo "<tr><td>". $row["doc_id"] ."</td><td>". $row["doc_name"] ."</td><td>". $row["doc_type"] ."</td></tr>";					
					}
						echo "</table>";
			}
			else {
				echo "0 result";
			}
			$conn-> close();
		?>

	</table>

	<br>
	<br>
	<a href="doctor_list_type.php">
		<button>Back</button>
	</a>
	<a href="patient_profile.php">
		<button>Main Menu</button>
	</a>
	
</body>
</html>

