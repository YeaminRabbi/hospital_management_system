<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form method="post" action="Patient_medicine_check.php">
	

<h3>Doctor Searh by Medicine</h3>
	<input type="text" name="doctorname">
	<input type="submit" name="Searh" value="Search">



</form>

	
</body>
</html>