<!DOCTYPE HTML>
<html>
<head>
  <title>Register Form</title>
</head>
<body>

 <form action="Register_index.php" method="POST">
  

  <table>


   <tr>
    <td>Name :</td>
    <td><input type="text" name="name" required></td>
   </tr>




   <tr>
    <td>Username :</td>
    <td><input type="text" name="username" required></td>
   </tr>
   <tr>



   <tr>
    <td>Password :</td>
    <td><input type="password" name="password" required></td>
   </tr>

   <tr>
    <td>Email :</td>
    <td><input type="email" name="email"></td>
   </tr> 


   <tr>
    <td>Gender :</td>
    <td>
     <input type="radio" name="gender" value="male" required>Male
     <input type="radio" name="gender" value="female" required>Female
    </td>
   </tr>  
   


   <td>Birthdate :</td>
   <td><input type="date" name="birthdate" required></td>
   </tr>


   <td>Age :</td>
   <td><input type="text" name="age" required></td>
   </tr>


   <tr>
    <td>Address :</td>
    <td><input type="text" name="address" required></td>
   </tr>
   
   <tr>
    <td>Phone no :</td>
    <td>
     <input type="phone" name="phone" required>
    </td>
   </tr>
   <tr>
    <td><input type="submit" value="Submit"></td>
   </tr>

  </table>
 </form>
</body>
</html>