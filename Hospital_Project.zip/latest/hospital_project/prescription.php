<?php

session_start();
$serial= $_SESSION['serial'];
$doctor_username=$_SESSION['doc_username'];


$medicine_name= $_POST['med'];
#$appoint_docID= $_POST['input_docID'];
#$patient_username= $_SESSION['username'];
$patient_id= "";


$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "hospital";

    //DATABASE connection
    $connect = mysqli_connect($hostname, $username, $password, $databaseName);


    ######fetching patient id usind appointment_id || Serial
	$query ="SELECT * FROM `appointment` where ap_id='$serial' ";

	$result2 = mysqli_query($connect, $query);

	$row2 = mysqli_fetch_array($result2);

	$patient_id= $row2[1];
	$doctor_id= $row2[2];
	#$patient_name= $row2[1];
	#$patient_email=$row2[5];

	#########fetching doctor id using session doctor username



#######database insert

	$query2 = "INSERT INTO prescription 
        VALUES ('','$medicine_name','$patient_id','505','$doctor_id', '$serial')";
        $a = mysqli_query($connect, $query2);



        echo "<script>location.assign('index.php');</script>";





  ?>