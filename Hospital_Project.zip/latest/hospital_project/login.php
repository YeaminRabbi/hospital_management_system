<!DOCTYPE html>

<html>

	<head>
		<title>Hospital Management</title>

		<style>
			*{
			 margin: 0px;
			 padding: 0px;
			 box-sizing: border-box;
	         font-family: sans-serif;
		    }
		   body{
		background-image: url('images/hospitalback.jpg');
		background-size: cover;
		background-attachment: fixed;
		}
		.panel{
			width: 300px;
			height: 430px;
			background: #F5F5DC;
			border-radius: 6px;
			position: absolute;
			text-align: center;
			box-shadow: 0px 1px 10px 1px #000;
			left: 40%;
			top: 20%;

		}
		.text{
			padding-top: 20px;
			border-bottom: 5px solid;
		}
		.login{
			padding-top: 60px;
		}
		.textbox input{
			width: 75%;
			overflow: hidden;
			font-size: 20px;
			padding: 8px 0;
			margin: 8px 0;
			border: 3px solid black;
		}

		.btn input{
			width: 50%;
			background: none;
			border: 2px solid black;
			font-size: 15px;
			font-weight: bold;
		}
		.back {
			margin-left: 25%;
			margin-top: 8px;
			width: 50%;
			background: none;
			border: 2px solid black;
			font-size: 15px;
		}
		.back a{
			text-decoration: none;
			color: black;
			font-weight: bold;

		}
		</style>
	</head>

	<body>
		<form action="" method="post">

	<div class="panel">
		<div class="text">
			<h1>Log In</h1>
		</div>
		
		<div class=login>
			<div class="textbox">
    	<input type="text" name="username" required placeholder="username">
		</div>
    	
    	<br>
    	<div class="textbox">
   		<input type="password" name="password" required placeholder="password">
    	</div>
    	<br>
    	<div class="btn">
    		<input type="submit" value="Sign in">
    	</div>
    	<div class="back">
    		<a href="index.html">Back</a>
    	</div>
		</div>
		
    	
	</div>
    
		</form>
	</body>

</html>

<?php

$username="";
$password="";

if( isset($_POST['username']) ){
	$username=$_POST['username'];
}

if( isset($_POST['password']) ){
	$password=$_POST['password'];
}


///database connection
try{
	$conn = new PDO("mysql:host=localhost;dbname=hospital;","root","");
}
catch(PDOException $err){
	echo "<script>window.alert('db connection error');</script>";
		echo "<script>location.assign('login.php');</script>";
}


$pateintprofile=0;
$doctorprofile=0;
$adminprofile=0;

########patient part######
$sqlquery="SELECT * FROM patient WHERE p_username='$username' AND p_password='$password'";

$object=$conn->query($sqlquery);
if($object->rowCount()==1){
	#echo "<script>location.assign('patient_profile.php');</script>";
	$pateintprofile=1;
}

#######doctor part#####
$sqlquery1="SELECT * FROM doctor WHERE doc_username='$username' AND doc_password='$password'";

$object1=$conn->query($sqlquery1);
if($object1->rowCount()==1){
	#echo "<script>location.assign('patient_profile.php');</script>";
	$doctorprofile=1;
}


#########admin part#########
$sqlquery2="SELECT * FROM admin WHERE Username='$username' AND Password='$password'";

$object2=$conn->query($sqlquery2);
if($object2->rowCount()==1){
	#echo "<script>location.assign('patient_profile.php');</script>";
	$adminprofile=1;
}

session_start();

if($pateintprofile==1)
{
	$_SESSION['username'] = $username;
	
	echo "<script>location.assign('patient_profile.php');</script>";
}

if($adminprofile==1)
{
	echo "<script>location.assign('admin_work.php');</script>";
}

if($doctorprofile==1)
{

	$_SESSION['doc_username'] = $username;
	echo "<script>location.assign('doctor_profile.php');</script>";
}
?>