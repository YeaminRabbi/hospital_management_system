<?php

$age= $_POST['age'];
$birthdate= $_POST['birthdate'];
$name= $_POST['name'];
$address= $_POST['address'];
$name= $_POST['name'];
$username = $_POST['username'];
$password = $_POST['password'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$phone = $_POST['phone'];
if (!empty($username) || !empty($password) || !empty($gender) || !empty($email) || !empty($address) || !empty($phone)|| !empty($name)) 
{
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "hospital";

    //DATABASE connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    
    if (mysqli_connect_error()) {
        die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    }

    else {

    
        $query = "INSERT INTO patient 
        VALUES ('','$name','$birthdate','$gender','$phone','$email','$address','$username','$password','$age')";
        $a = mysqli_query($conn, $query);
      

    $to="";
    $to= $email;

    $message="Your Username: $username\n Your Password: $password";
    
    #$to= "yeaminrabbi308@gmail.com";
    $subject= "PHP Email";
    #$message= "Vector a Pass kor agge";
    $headers= "From: DBMS<dbmsproject248266@gmail.com>";

    if(mail($to, $subject, $message,$headers))
    {
        echo "Mail Send";
        echo "<script>location.assign('login.php');</script>";
    }
    else
    {
        echo "Error REgistration";
    }

        

         
    }
   # echo "<script>location.assign('login.php');</script>"; 
} 
?>