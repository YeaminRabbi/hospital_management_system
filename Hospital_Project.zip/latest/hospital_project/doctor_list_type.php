<!DOCTYPE html>
<html>
<head>
	<title>Doctor Type List</title>
</head>
<body>
	<form  action = "doctor_list_type_index.php" method="POST">
		
		<h3>Searh Type:</h3>
		<select name="doctor_type" required>
      <option selected hidden value="">Select Type</option>
      <option value="Heart">Heart</option>
      <option value="Diabetic">Diabetic</option>
      <option value="Bone">Bone</option>
      <option value="Skin">Skin</option>
      
     </select>

     <input type="submit" value="Submit">
     
     

	</form>
	<br>
	<br>
	<a href="patient_profile.php">
     	<button>Back</button>
     </a>

	
</body>
</html>

