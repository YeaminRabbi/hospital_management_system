<?php
session_start();

$appoint_docID= $_POST['input_docID'];
$patient_username= $_SESSION['username'];
$patient_id= "";


$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "hospital";

    //DATABASE connection
    $connect = mysqli_connect($hostname, $username, $password, $databaseName);
	$query ="SELECT * FROM `patient` where p_username LIKE '$patient_username' ";

	$result2 = mysqli_query($connect, $query);

	$row2 = mysqli_fetch_array($result2);

	$patient_id= $row2[0];
	$patient_name= $row2[1];



	echo $patient_id;
	echo $patient_username;
	

	
if (!empty($appoint_docID) ) 
{
    
        $query2 = "INSERT INTO appointment 
        VALUES ('','$patient_id','$appoint_docID','101','$patient_username', '$patient_name')";
        $a = mysqli_query($connect, $query2);
         


        $sqlquery="
        UPDATE doctor
	set available=available+1
	where doc_id='$appoint_docID'";

		$aa=mysqli_query($connect, $sqlquery);

        echo "<script>location.assign('patient_profile.php');</script>";
    
    }


?>