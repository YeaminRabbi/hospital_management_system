<!DOCTYPE html>
<html>
<head>
	<title>Doctor List</title>
	<style type="text/css">
		.content{

			border-collapse: collapse;
			margin: 25px 0;
			font-size: 18px;
			min-width: 80%;
			border-radius: 5px;
			overflow: hidden;
			box-shadow: 0 0 20px rgb(0, 0, 0, 0.15);
		}
		.content thead tr{
			background-color: #009879;
			color: #ffffff;
			text-align: left;
			font-weight: bold;
		}
		.content th,
		.content td{
			padding: 12px 15px;
		}
		.content tr{
			border-bottom: 1px solid #dddddd;
		}
		.content tr:nth-of-type(even){
			background-color: #f3f3f3;
		}
		.content tr:last-of-type{
			border-bottom: 2px solid  #009879;
		}
		.bt1 a{
			text-decoration: none;
			color: white;
		}
		.bt1{
			padding: 5px;
			display: block;
			list-style: none;
			border: 2px solid black;
			font-size: 15px;
			font-weight: bold;
			border-radius: 15px;
			text-align: center;
			background: #009879;
			margin-left: 10%;
			margin-right: 85%;
			margin-bottom: 5px;
		}
		.bt2 a{
			text-decoration: none;
			color: white;
		}
		.bt2{
			padding: 5px;
			display: block;
			list-style: none;
			border: 2px solid black;
			font-size: 15px;
			font-weight: bold;
			border-radius: 15px;
			text-align: center;
			background: #009879;
			margin-left: 10%;
			margin-right: 80%;
		}

	</style>
</head>
<body>


	<table class="content">
		<thead>
			<tr>
				<th>Name</th>
				<th>Contact No.</th>
				<th>Type</th>
			</tr>
		</thead>
		

		<?php

			$doc_type=$_POST['doctor_type'];

			$conn = mysqli_connect("localhost", "root", "", "hospital");

			if($conn-> connect_error)
			{
				die("Connection failed:". $conn-> connect_error);
			}

			$sql = "SELECT doc_name, doc_mobile, doc_type from doctor
			WHERE doc_type = '$doc_type'";
			$result = $conn-> query($sql);
			if($result-> num_rows >0)
			{
				while ($row = $result-> fetch_assoc()) {
						echo "<tr><td>". $row["doc_name"] ."</td><td>". $row["doc_mobile"] ."</td><td>". $row["doc_type"] ."</td></tr>";					
					}
						echo "</table>";
			}
			else {
				echo "0 result";
			}
			$conn-> close();
		?>

	</table>

	<br>
	<br>
		<div class="bt1">
			<a href="doctor_list_type.php">Back</a>
		</div>
		<div class="bt2">
			<a href="patient_profile.php">Main Menu</a>
		</div>
	
	
</body>
</html>

