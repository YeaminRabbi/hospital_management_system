


<!DOCTYPE html>
<html>
<head>
	<title>Patient Profile</title>
</head>
<style>

	*{
		margin: 0px;
	    padding: 0px;
	    box-sizing: border-box;
	    font-family: sans-serif;
	}
	body{
		background-image: url('images/hospitalback.jpg');
		background-size: cover;
		background-attachment: fixed;
	}
	.panel{
		width: 400px;
		height: 700px;
		background: #FFE4C4;
		border-radius: 6px;
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		box-shadow: 0px 1px 10px 1px #000;
		overflow: hidden;
		display: inline-block;
		margin-bottom: 25px;
	}
	ul{
		padding: 0px;
		margin: 0px;
	}
	ul li{
		list-style: none;
		border: 2px solid black;
		font-size: 15px;
		font-weight: bold;
		margin: 30px;
		border-radius: 7px;
	}
	ul li a{
		text-decoration: none;
		padding: 5px;
		display: block;
		text-align: center;
	}
	
</style>
<body>
	<div class="panel">
		<ul>
			<li><a href="doctor_list_index.php">Doctor List</a></li>
			<li><a href="doctor_list_type.php">Doctor Type</a></li>
			<li><a href="appointment.php">Appointment</a></li>
			<li><a href="Patient_appointment_check.php">Check Appointments</a></li>
			<li><a href="Patient_medicine_check1.php">Check Medicine List</a></li>
			<li><a href="login.php">Logout</a></li>
		</ul>
</body>
</html>

