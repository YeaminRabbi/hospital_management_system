-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2019 at 07:43 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Username` varchar(66) NOT NULL,
  `Password` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Username`, `Password`) VALUES
('yeamin', 248),
('mohit', 171);

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `ap_id` int(5) NOT NULL,
  `patientp_id` int(5) NOT NULL,
  `doctordoc_id` int(5) NOT NULL,
  `receptionistrec_id` int(5) NOT NULL,
  `patient_username` varchar(99) DEFAULT NULL,
  `patient_name` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`ap_id`, `patientp_id`, `doctordoc_id`, `receptionistrec_id`, `patient_username`, `patient_name`) VALUES
(12, 9, 102, 101, 'jony', 'jony'),
(13, 9, 107, 101, 'jony', 'jony'),
(14, 9, 107, 101, 'jony', 'jony'),
(15, 7, 101, 101, 'yeamin248', 'Yeamin Rabbi');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `bill_id` int(5) NOT NULL,
  `bill_amount` double NOT NULL,
  `receptionistrec_id` int(5) NOT NULL,
  `patientp_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doc_id` int(5) NOT NULL,
  `doc_name` varchar(20) NOT NULL,
  `doc_birthdate` date NOT NULL,
  `doc_gender` varchar(6) NOT NULL,
  `doc_degree` varchar(50) NOT NULL,
  `doc_mobile` char(11) NOT NULL,
  `doc_email` varchar(30) NOT NULL,
  `doc_address` varchar(40) NOT NULL,
  `doc_password` varchar(30) NOT NULL,
  `doc_username` varchar(20) NOT NULL,
  `doc_type` varchar(188) DEFAULT NULL,
  `available` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doc_id`, `doc_name`, `doc_birthdate`, `doc_gender`, `doc_degree`, `doc_mobile`, `doc_email`, `doc_address`, `doc_password`, `doc_username`, `doc_type`, `available`) VALUES
(101, 'Dr.Saklayen', '1980-10-08', 'male', 'MBBS', '01968004455', 'saklayen@gmail.com', 'Bangladesh', '1234', 'saklayen', 'Diabetic', 1),
(102, 'Dr. Hamidur', '1980-10-08', 'male', 'MBBS,FCPS', '01322004455', 'hamidur@gmail.com', 'Bangladesh', '1234', 'hamidur', 'Diabetic', 0),
(103, 'Dr. Rokeya', '1960-01-17', 'female', 'MBBS,FCPS,FACC', '01912804411', 'rokeya@gmail.com', 'Bangladesh', '1234', 'rokeya', 'Bone', 0),
(104, 'Dr. Sultana Rahman', '1985-09-10', 'female', 'MBBS,FACC', '01817704411', 'sultana@gmail.com', 'Bangladesh', '1234', 'sultana', 'Bone', 0),
(105, 'Dr. Siraj Rahman', '1969-10-08', 'male', 'MBBS,FRCS', '01912800001', 'siraj@gmail.com', 'Bangladesh', '1234', 'siraj', 'Heart', 0),
(106, 'Dr. Mashhud Haq', '1970-10-17', 'male', 'MBBS,FCPS,DTCD', '01912809009', 'mashhud@gmail.com', 'Bangladesh', '1234', 'mashhud', 'Heart', 0),
(107, 'Dr. Liton Hossain', '1990-11-26', 'male', 'MBBS,FCPS', '01916604411', 'liton@gmail.com', 'Bangladesh', '1234', 'liton', 'Skin', 2);

-- --------------------------------------------------------

--
-- Table structure for table `laboratorist`
--

CREATE TABLE `laboratorist` (
  `lab_id` int(5) NOT NULL,
  `lab_name` varchar(20) NOT NULL,
  `lab_birthdate` date NOT NULL,
  `lab_gender` varchar(6) NOT NULL,
  `lab_degree` varchar(50) NOT NULL,
  `lab_mobile` char(11) NOT NULL,
  `lab_email` varchar(30) NOT NULL,
  `lab_address` varchar(40) NOT NULL,
  `lab_username` varchar(20) NOT NULL,
  `lab_passeword` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `med_id` int(10) NOT NULL,
  `med_name` varchar(200) NOT NULL,
  `med_type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`med_id`, `med_name`, `med_type`) VALUES
(1, 'Sugatrol 100mg', 'Diabetic'),
(2, 'Politor 500', 'Diabetic'),
(3, 'Glitamin 500mg', 'Diabetic'),
(4, 'Insul 50/50 injection', 'Diabetic'),
(5, 'Formin 850', 'Diabetic'),
(6, 'Betafix 2.5g', 'Heart'),
(7, 'Bisocor 5mg', 'Heart'),
(8, 'Aspirin', 'Heart'),
(9, 'Altace', 'Heart'),
(10, 'Brilinta', 'Heart'),
(11, 'Cholecalciferol', 'Bone'),
(12, 'Calcium', 'Bone'),
(13, 'Resedronic Acid', 'Bone'),
(14, 'Prolia', 'Bone'),
(15, 'Forteo', 'Bone'),
(16, 'Bensalic', 'Skin'),
(17, 'Benzoic', 'Skin'),
(18, 'Dermin Ointment', 'Skin'),
(19, 'Dermazol', 'Skin'),
(20, 'Fungalin', 'Skin');

-- --------------------------------------------------------

--
-- Table structure for table `medicine_list`
--

CREATE TABLE `medicine_list` (
  `med_id` int(5) NOT NULL,
  `med_name` varchar(15) NOT NULL,
  `med_mgf` date NOT NULL,
  `med_exp` date NOT NULL,
  `med_price` double NOT NULL,
  `prescriptionpre_id` int(5) NOT NULL,
  `Pharmacistpha_id` int(5) NOT NULL,
  `doctordoc_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `p_id` int(5) NOT NULL,
  `p_name` varchar(20) NOT NULL,
  `p_birthdate` date NOT NULL,
  `p_gender` varchar(6) NOT NULL,
  `p_mobile` char(11) NOT NULL,
  `p_email` varchar(30) NOT NULL,
  `p_address` varchar(40) NOT NULL,
  `p_username` varchar(20) NOT NULL,
  `p_password` varchar(30) NOT NULL,
  `p_age` varchar(110) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`p_id`, `p_name`, `p_birthdate`, `p_gender`, `p_mobile`, `p_email`, `p_address`, `p_username`, `p_password`, `p_age`) VALUES
(1, 'johncena', '2019-08-08', 'male', '01768002727', 'supti.debnath@gmail.com', 'bangladesh', 'john_cena', '123', '30'),
(2, 'mohit', '0000-00-00', 'male', '01688079678', 'mkarim171266@bscse.uiu.ac.bd', 'bd', 'mk', '111', '45'),
(7, 'Yeamin Rabbi', '2019-08-06', 'male', '12345678909', 'yeaminrabbi308@gmail.com', 'Dhaka, Bangladesh', 'yeamin248', '248', '25'),
(8, 'abid', '2018-11-14', 'male', '1234567654', 'abidur.rahman2010@gmail.com', 'bagura', 'abid', '1212', '27'),
(9, 'jony', '2019-08-14', 'male', '01768002727', 'yeaminrabbi308@gmail.com', 'bangladesh', 'jony', '1234', '18'),
(10, 'uiu', '2019-08-16', 'male', '01768002727', 'yakram171248@bscse.uiu.ac.bd', 'bangladesh', 'uiucampus', '1234', '14');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

CREATE TABLE `pharmacist` (
  `pha_id` int(5) NOT NULL,
  `pha_name` varchar(20) NOT NULL,
  `pha_birthdate` date NOT NULL,
  `pha_gender` varchar(6) NOT NULL,
  `pha_degree` varchar(50) NOT NULL,
  `pha_mobile` char(11) NOT NULL,
  `pha_email` varchar(30) NOT NULL,
  `pha_address` varchar(40) NOT NULL,
  `pha_username` varchar(20) NOT NULL,
  `pha_password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacist`
--

INSERT INTO `pharmacist` (`pha_id`, `pha_name`, `pha_birthdate`, `pha_gender`, `pha_degree`, `pha_mobile`, `pha_email`, `pha_address`, `pha_username`, `pha_password`) VALUES
(505, 'kamal', '2019-08-20', 'male', 'HSC, Diploma', '09876543212', 'kamal@gmail.com', 'dhaka', 'kamal', '123');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `pre_id` int(5) NOT NULL,
  `pre_med` varchar(255) NOT NULL,
  `patientp_id` int(5) NOT NULL,
  `Pharmacistpha_id` int(5) NOT NULL,
  `doctordoc_id` int(5) NOT NULL,
  `appointment_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`pre_id`, `pre_med`, `patientp_id`, `Pharmacistpha_id`, `doctordoc_id`, `appointment_id`) VALUES
(31, 'Altace', 9, 505, 102, 12),
(32, 'Benzoic', 9, 505, 102, 12),
(33, 'Calcium', 9, 505, 102, 12),
(34, 'Bensalic', 9, 505, 107, 14),
(35, 'Altace', 7, 505, 101, 15),
(36, 'Cholecalciferol', 7, 505, 101, 15);

-- --------------------------------------------------------

--
-- Table structure for table `receptionist`
--

CREATE TABLE `receptionist` (
  `rec_id` int(5) NOT NULL,
  `rec_name` varchar(20) NOT NULL,
  `rec_birthdate` date NOT NULL,
  `rec_gender` varchar(6) NOT NULL,
  `rec_mobile` char(11) NOT NULL,
  `rec_email` varchar(30) NOT NULL,
  `rec_address` varchar(40) NOT NULL,
  `rec_degree` varchar(50) NOT NULL,
  `rec_username` varchar(20) NOT NULL,
  `rec_password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receptionist`
--

INSERT INTO `receptionist` (`rec_id`, `rec_name`, `rec_birthdate`, `rec_gender`, `rec_mobile`, `rec_email`, `rec_address`, `rec_degree`, `rec_username`, `rec_password`) VALUES
(101, 'HR', '2019-08-13', 'Male', '01911297928', 'recep@gmail.com', 'dhaka', 'RECEPT', 'HR', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `test_id` int(5) NOT NULL,
  `test_date` date NOT NULL,
  `report` varchar(100) NOT NULL,
  `doctordoc_id` int(5) NOT NULL,
  `laboratoristlab_id` int(5) NOT NULL,
  `patientp_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`ap_id`),
  ADD KEY `FKappointmen517899` (`patientp_id`),
  ADD KEY `FKappointmen934328` (`doctordoc_id`),
  ADD KEY `FKappointmen23019` (`receptionistrec_id`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`bill_id`),
  ADD KEY `FKBill955677` (`receptionistrec_id`),
  ADD KEY `FKBill450558` (`patientp_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doc_id`),
  ADD UNIQUE KEY `doc_mobile` (`doc_mobile`),
  ADD UNIQUE KEY `doc_email` (`doc_email`),
  ADD UNIQUE KEY `doc_username` (`doc_username`);

--
-- Indexes for table `laboratorist`
--
ALTER TABLE `laboratorist`
  ADD PRIMARY KEY (`lab_id`),
  ADD UNIQUE KEY `lab_mobile` (`lab_mobile`),
  ADD UNIQUE KEY `lab_email` (`lab_email`),
  ADD UNIQUE KEY `lab_username` (`lab_username`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`med_id`);

--
-- Indexes for table `medicine_list`
--
ALTER TABLE `medicine_list`
  ADD PRIMARY KEY (`med_id`),
  ADD KEY `FKmedicine_l89664` (`prescriptionpre_id`),
  ADD KEY `FKmedicine_l118517` (`Pharmacistpha_id`),
  ADD KEY `FKmedicine_l652730` (`doctordoc_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`p_id`),
  ADD UNIQUE KEY `p_username` (`p_username`);

--
-- Indexes for table `pharmacist`
--
ALTER TABLE `pharmacist`
  ADD PRIMARY KEY (`pha_id`),
  ADD UNIQUE KEY `pha_mobile` (`pha_mobile`),
  ADD UNIQUE KEY `pha_email` (`pha_email`),
  ADD UNIQUE KEY `pha_username` (`pha_username`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`pre_id`),
  ADD KEY `FKprescripti780670` (`patientp_id`),
  ADD KEY `FKprescripti830027` (`Pharmacistpha_id`),
  ADD KEY `FKprescripti635758` (`doctordoc_id`),
  ADD KEY `appointment_id` (`appointment_id`);

--
-- Indexes for table `receptionist`
--
ALTER TABLE `receptionist`
  ADD PRIMARY KEY (`rec_id`),
  ADD UNIQUE KEY `rec_mobile` (`rec_mobile`),
  ADD UNIQUE KEY `rec_email` (`rec_email`),
  ADD UNIQUE KEY `rec_username` (`rec_username`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`test_id`),
  ADD KEY `FKtest381055` (`doctordoc_id`),
  ADD KEY `FKtest512680` (`laboratoristlab_id`),
  ADD KEY `FKtest964625` (`patientp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `ap_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `bill_id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doc_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `laboratorist`
--
ALTER TABLE `laboratorist`
  MODIFY `lab_id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `med_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `medicine_list`
--
ALTER TABLE `medicine_list`
  MODIFY `med_id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `p_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pharmacist`
--
ALTER TABLE `pharmacist`
  MODIFY `pha_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=506;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `pre_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `receptionist`
--
ALTER TABLE `receptionist`
  MODIFY `rec_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `test_id` int(5) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `FKappointmen23019` FOREIGN KEY (`receptionistrec_id`) REFERENCES `receptionist` (`rec_id`),
  ADD CONSTRAINT `FKappointmen517899` FOREIGN KEY (`patientp_id`) REFERENCES `patient` (`p_id`),
  ADD CONSTRAINT `FKappointmen934328` FOREIGN KEY (`doctordoc_id`) REFERENCES `doctor` (`doc_id`);

--
-- Constraints for table `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `FKBill450558` FOREIGN KEY (`patientp_id`) REFERENCES `patient` (`p_id`),
  ADD CONSTRAINT `FKBill955677` FOREIGN KEY (`receptionistrec_id`) REFERENCES `receptionist` (`rec_id`);

--
-- Constraints for table `medicine_list`
--
ALTER TABLE `medicine_list`
  ADD CONSTRAINT `FKmedicine_l118517` FOREIGN KEY (`Pharmacistpha_id`) REFERENCES `pharmacist` (`pha_id`),
  ADD CONSTRAINT `FKmedicine_l652730` FOREIGN KEY (`doctordoc_id`) REFERENCES `doctor` (`doc_id`),
  ADD CONSTRAINT `FKmedicine_l89664` FOREIGN KEY (`prescriptionpre_id`) REFERENCES `prescription` (`pre_id`);

--
-- Constraints for table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `FKprescripti635758` FOREIGN KEY (`doctordoc_id`) REFERENCES `doctor` (`doc_id`),
  ADD CONSTRAINT `FKprescripti780670` FOREIGN KEY (`patientp_id`) REFERENCES `patient` (`p_id`),
  ADD CONSTRAINT `FKprescripti830027` FOREIGN KEY (`Pharmacistpha_id`) REFERENCES `pharmacist` (`pha_id`),
  ADD CONSTRAINT `prescription_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`ap_id`);

--
-- Constraints for table `test`
--
ALTER TABLE `test`
  ADD CONSTRAINT `FKtest381055` FOREIGN KEY (`doctordoc_id`) REFERENCES `doctor` (`doc_id`),
  ADD CONSTRAINT `FKtest512680` FOREIGN KEY (`laboratoristlab_id`) REFERENCES `laboratorist` (`lab_id`),
  ADD CONSTRAINT `FKtest964625` FOREIGN KEY (`patientp_id`) REFERENCES `patient` (`p_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
